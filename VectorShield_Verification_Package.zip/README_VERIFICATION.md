# Vector-Shield: Verification Package & Metric Audit Guide
**Prepared for:** Dr. Lekshmi C. R., Project Supervisor & Advisor  
**Department of Artificial Intelligence**, Amrita Vishwa Vidyapeetham, Coimbatore  
**Team 14:** Vignesh V S, Karthick Ruban T, Sanjay Senthil, Hari Prakash V  

---

## 📦 Contents of This Verification Package
1. **`classifier_core.pt`**: Native PyTorch trained neural checkpoint (522 KB) containing the fine-tuned ModernBERT classification projection weights.
2. **`verify_checkpoint.py`**: Standalone executable Python verification script to load the checkpoint, verify parameter count, and benchmark inference latency.
3. **`training_loss_curves.png`**: Empirical loss convergence graph across Epochs 1, 2, and 3 trained on the NVIDIA A100 GPU (Mixed Precision FP16).
4. **`adversarial_density_manifold.png`**: High-dimensional manifold projection demonstrating the geometric separation between corporate policy inliers and adversarial outliers.
5. **`latency_comparison.png`**: Latency profile comparing Vector-Shield (1.82 ms Stage 1, 12.2 ms Stage 2) against LLM-based guardrails (Llama Guard: >1200 ms).
6. **`lof_density_distribution.png`**: Distribution graph showing density scores and safe vs. quarantine thresholds.

---

## ⚡ How to Verify the Checkpoint Locally
You can run the verification script in any standard Python environment with `torch` and `numpy`:
```bash
python verify_checkpoint.py
```
This loads `classifier_core.pt`, executes the neural forward pass, and prints the verified classification metrics and execution latency.

---

## 🌐 Live Interactive Cloud Verification
You can also verify the model live on our cloud dashboard:
- **URL:** [https://vectorshield.streamlit.app/](https://vectorshield.streamlit.app/)
- **Tab 2 (Stage 2 ModernBERT Inspection):** Test any custom query to inspect real-time neural injection probabilities and latency gauges.
- **Tab 4 (3D Vector Hyperspace):** Inspect the 3D PCA manifold projection of verified documents vs. adversarial payloads.
- **Tab 5 (Architecture & Topology):** Review the live mathematical formulas and benchmark latency tracking.

---
*Vector-Shield Project | School of AI & Data Science | Amrita Vishwa Vidyapeetham*
